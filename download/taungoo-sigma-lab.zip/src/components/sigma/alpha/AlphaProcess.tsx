"use client";

import * as React from "react";

const STEPS: { num: string; title: string; desc: string; color: string; deliverables: string[]; duration: string }[] = [
  { num: "01", title: "DISCOVERY", color: "#FF4500", duration: "1-2 weeks", desc: "Deep dive into requirements, constraints, and goals. We define scope, timeline, and success metrics.", deliverables: ["Scope document", "Timeline estimate", "Tech stack proposal", "Risk assessment"] },
  { num: "02", title: "ARCHITECTURE", color: "#00E5FF", duration: "1 week", desc: "System design, tech stack selection, and infrastructure planning. Architecture diagrams, API contracts, database schemas.", deliverables: ["Architecture diagrams", "API contracts", "Database schemas", "Infrastructure plan"] },
  { num: "03", title: "BUILD", color: "#C6FF00", duration: "2-8 weeks", desc: "Rapid development with CI/CD, automated testing, and daily deployments to staging. You see progress every day.", deliverables: ["Daily staging deploys", "Automated tests", "Code reviews", "Progress dashboard"] },
  { num: "04", title: "DEPLOY", color: "#00FF94", duration: "1 week +", desc: "Production deployment with monitoring, documentation, and handoff. We don't ship and forget.", deliverables: ["Production deployment", "Monitoring setup", "Documentation", "30-day support"] },
];

const PRINCIPLES: { icon: string; text: string; color: string }[] = [
  { icon: "◐", text: "PRODUCTION-FIRST", color: "#00FF94" },
  { icon: "⬡", text: "MULTI-MODEL AI", color: "#00E5FF" },
  { icon: "▤", text: "DOCUMENTED", color: "#C6FF00" },
  { icon: "⚙", text: "SUPPORTED", color: "#FFB300" },
  { icon: "◴", text: "DAILY DEPLOYS", color: "#FF2D7E" },
  { icon: "⚿", text: "SECURITY AUDITED", color: "#FF3D3D" },
  { icon: "◍", text: "OPEN COMMUNICATION", color: "#B388FF" },
  { icon: "✦", text: "30-DAY WARRANTY", color: "#FFEB3B" },
];

export function AlphaProcess() {
  return (
    <section id="process" className="relative border-t border-border px-3 py-20">
      <div className="sigma-grid pointer-events-none absolute inset-0 opacity-10" />
      <div className="sigma-scanlines pointer-events-none absolute inset-0 opacity-15" />

      <div className="relative z-10 mx-auto w-full max-w-[1600px]">
        {/* Header */}
        <div className="flex items-end justify-between gap-4 border-b border-border pb-4">
          <div>
            <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#FF4500]">▸ 05 / PROCESS</div>
            <h2 className="mt-2 font-sans text-4xl font-black uppercase tracking-tight sm:text-6xl">
              OUR <span style={{ color: "#FF4500" }}>PROCESS.</span>
            </h2>
            <p className="mt-2 font-serif text-base italic text-muted-foreground">4 phases. Zero black boxes. Every deliverable documented.</p>
          </div>
          <div className="hidden shrink-0 font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground sm:block">
            <span className="text-[#FF4500]">4</span> PHASES · <span className="text-[#00FF94]">16</span> DELIVERABLES
          </div>
        </div>

        {/* === PRINCIPLES BAR — maximalist, fills negative space === */}
        <div className="mt-4 flex flex-wrap gap-1">
          {PRINCIPLES.map((p) => (
            <div key={p.text} className="flex items-center gap-1.5 border border-border/40 bg-card/20 px-2 py-1">
              <span className="font-sans text-xs" style={{ color: p.color }}>{p.icon}</span>
              <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-muted-foreground">{p.text}</span>
            </div>
          ))}
        </div>

        {/* === PROCESS CARDS — horizontal sci-fi, tight spacing === */}
        <div className="mt-4 space-y-2">
          {STEPS.map((s, idx) => (
            <div
              key={s.num}
              className="group relative flex border border-border bg-card/30 transition-all hover:border-foreground/40"
              style={{ clipPath: "polygon(20px 0, 100% 0, 100% calc(100% - 20px), calc(100% - 20px) 100%, 0 100%, 0 20px)" }}
            >
              {/* Left: Number + accent */}
              <div className="relative flex w-24 shrink-0 flex-col items-center justify-center border-r border-border/40" style={{ background: `linear-gradient(135deg, ${s.color}15, transparent)` }}>
                <span className="sigma-glitch font-sans text-4xl font-black leading-none" data-text={s.num} style={{ color: s.color }}>{s.num}</span>
                <span className="mt-0.5 font-mono text-[6px] uppercase tracking-[0.14em] text-muted-foreground">{s.duration}</span>
                <div className="absolute bottom-0 left-0 h-1 w-full" style={{ background: `repeating-linear-gradient(45deg, ${s.color} 0, ${s.color} 3px, transparent 3px, transparent 6px)` }} />
              </div>

              {/* Middle: Title + desc + deliverables inline */}
              <div className="flex-1 p-3">
                <div className="flex items-center gap-2">
                  <h3 className="font-sans text-sm font-bold uppercase tracking-tight">{s.title}</h3>
                  <span className="font-mono text-[7px] uppercase tracking-[0.14em]" style={{ color: s.color }}>PHASE {s.num}</span>
                  {/* Phase connector inline */}
                  {idx < STEPS.length - 1 && <span className="font-mono text-xs text-muted-foreground/30">→</span>}
                  {idx === STEPS.length - 1 && <span className="font-mono text-xs" style={{ color: s.color }}>✓ SHIPPED</span>}
                </div>
                <p className="mt-1 font-serif text-xs italic text-muted-foreground">{s.desc}</p>
                {/* Deliverables — inline tags */}
                <div className="mt-2 flex flex-wrap gap-0.5">
                  {s.deliverables.map((d) => (
                    <span key={d} className="border px-1.5 py-0.5 font-mono text-[7px] uppercase tracking-[0.1em] text-muted-foreground" style={{ borderColor: `${s.color}33` }}>
                      <span style={{ color: s.color }}>▸</span> {d}
                    </span>
                  ))}
                </div>
              </div>

              {/* Scanlines */}
              <div className="pointer-events-none absolute inset-0 z-0 opacity-10" style={{ background: "repeating-linear-gradient(0deg, transparent 0px, transparent 2px, rgba(0,0,0,0.15) 3px, rgba(0,0,0,0.15) 4px)" }} />
              {/* Hover glow */}
              <div className="pointer-events-none absolute inset-0 z-0 opacity-0 transition-opacity group-hover:opacity-100" style={{ background: `radial-gradient(60% 50% at 50% 50%, ${s.color}08, transparent 70%)` }} />
            </div>
          ))}
        </div>

        {/* === STATS ROW — fills bottom negative space === */}
        <div className="mt-4 grid grid-cols-2 gap-px border border-border/40 bg-border/40 sm:grid-cols-4">
          {[
            ["4-11", "WEEKS TYPICAL", "#FF4500"],
            ["16", "DELIVERABLES", "#00E5FF"],
            ["100%", "TRANSPARENT", "#C6FF00"],
            ["30D", "SUPPORT", "#00FF94"],
          ].map(([v, k, c]) => (
            <div key={k} className="bg-card/40 p-3">
              {/* Hazard top strip */}
              <div className="mb-1 h-0.5 w-full" style={{ background: `repeating-linear-gradient(45deg, ${c} 0, ${c} 3px, transparent 3px, transparent 6px)` }} />
              <div className="font-sans text-xl font-black" style={{ color: c }}>{v}</div>
              <div className="font-mono text-[8px] uppercase tracking-[0.16em] text-muted-foreground">{k}</div>
            </div>
          ))}
        </div>

        {/* === ASCII TIMELINE — maximalist text decoration === */}
        <div className="mt-4 border border-border/40 bg-black/40 p-3 font-mono text-[8px] leading-tight text-muted-foreground/40">
          <div>┌─ DISCOVERY ─┬─ ARCHITECTURE ─┬─ BUILD ─┬─ DEPLOY ─┐</div>
          <div>│  ████████   │  ████████████   │ ██████████████ │ ████████████ │</div>
          <div>│  Week 1-2   │  Week 3        │ Week 4-10     │ Week 11+     │</div>
          <div>│  SCOPE      │  DESIGN        │ CODE          │ SHIP         │</div>
          <div>└─────────────┴────────────────┴───────────────┴─────────────┘</div>
          <div className="mt-1 text-[#00FF94]">▶ STATUS: ALL PHASES COMPLETE · 100% DELIVERY RATE · 0 BLACK BOXES</div>
        </div>
      </div>
    </section>
  );
}
